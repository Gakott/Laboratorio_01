/*
 * sevenseg.h
 *
 * Created: 21/01/2026 23:02:07
 *  Author: Usuario Dell
 */ 


#ifndef SEVENSEG_H_
#define SEVENSEG_H_

#include <avr/io.h>
#include <stdint.h>

// ===== CONFIGURACI�N DE HARDWARE =====
// Segmentos a..g conectados a PD0..PD6 (bit0..bit6)
#define SEVENSEG_PORT    PORTD
#define SEVENSEG_DDR     DDRD

// Si tu display es:
//  - C�TODO COM�N:0
//  - �NODO COM�N: 1
#define SEVENSEG_COMMON_ANODE  1

void sevenseg_init(void);
void sevenseg_show_digit(uint8_t digit);   // 0..9
void sevenseg_blank(void);

#endif /* SEVENSEG_H_ */