//********************************************************************************
//Universidad del Valle de Guatemala
//IE2023: Programacion de Microcontroladores
//Autor: Fernando Gabriel Caballeros Cu
//Proyecto: Laboratorio1.c
//Archivo: main.c
//Hardware: ATMega328P
//Created: 21/01/2026 22:45:58
//********************************************************************************

#define F_CPU 1000000UL

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>
#include "sevenseg.h"

// ================= BOTONES =================
#define BTN_START   PC0
#define BTN_J1      PC1
#define BTN_J2      PC2

static inline uint8_t raw_pressed(uint8_t bit)
{
	// Pull-up: presionado = 0
	return ((PINC & (1<<bit)) == 0);
}

// ================= TIMER0 1ms =================
volatile uint32_t g_ms = 0;
ISR(TIMER0_COMPA_vect) { g_ms++; }

static void timer0_init_1ms(void)
{
	TCCR0A = (1<<WGM01);     // CTC
	TCCR0B = (1<<CS01);      // prescaler 8 (con F_CPU=1MHz)
	OCR0A  = 124;            // 1ms
	TIMSK0 = (1<<OCIE0A);
}

static uint32_t millis(void)
{
	uint32_t t;
	cli(); t = g_ms; sei();
	return t;
}

// ================= DEBOUNCE =================
typedef struct {
	uint8_t stable;     // 0 suelto, 1 presionado
	uint8_t counter;
	uint8_t event;      // flanco de presionado
	uint8_t bit;        // PC bit
} DebBtn;

#define SAMPLE_MS     5
#define DEBOUNCE_MS   25
#define THRESH        (DEBOUNCE_MS / SAMPLE_MS)

static DebBtn b_start = {0,0,0,BTN_START};
static DebBtn b_j1    = {0,0,0,BTN_J1};
static DebBtn b_j2    = {0,0,0,BTN_J2};
static uint32_t last_sample = 0;

static void debounce_update(DebBtn *b)
{
	uint8_t raw = raw_pressed(b->bit); // 1 = presionado

	if (raw == b->stable) {
		b->counter = 0;
		} else {
		if (b->counter < 255) b->counter++;
		if (b->counter >= THRESH) {
			b->stable = raw;
			b->counter = 0;
			if (b->stable) b->event = 1; // evento al presionar
		}
	}
}

static void debounce_task(void)
{
	uint32_t now = millis();
	if ((now - last_sample) >= SAMPLE_MS) {
		last_sample = now;
		debounce_update(&b_start);
		debounce_update(&b_j1);
		debounce_update(&b_j2);
	}
}

static uint8_t take_event(DebBtn *b)
{
	if (b->event) { b->event = 0; return 1; }
	return 0;
}

// ================= LEDs CONTADORES =================
// Jugador1
#define P1_MASK   ((1<<PB1)|(1<<PB2)|(1<<PB3)|(1<<PB4))

// Jugador 2
#define P2_MASK_B (1<<PB5)
#define P2_MASK_C ((1<<PC3)|(1<<PC4)|(1<<PC5))

static void leds_init(void)
{
	DDRB |= P1_MASK | P2_MASK_B;
	DDRC |= P2_MASK_C;

	PORTB &= ~(P1_MASK | P2_MASK_B);
	PORTC &= ~P2_MASK_C;
}

// Muestra el valor (0..15) en 4 LEDs.
static void leds_contadores(uint8_t p1, uint8_t p2)
{
	p1 &= 0x0F;
	p2 &= 0x0F;

	// Jugador 1
	uint8_t out1 = (p1 << 1) & P1_MASK;
	PORTB = (PORTB & ~P1_MASK) | out1;

	// Jjugador2 
	if (p2 & (1<<0)) PORTB |=  (1<<PB5);
	else            PORTB &= ~(1<<PB5);
	uint8_t outc = 0;
	if (p2 & (1<<1)) outc |= (1<<PC3);
	if (p2 & (1<<2)) outc |= (1<<PC4);
	if (p2 & (1<<3)) outc |= (1<<PC5);
	PORTC = (PORTC & ~P2_MASK_C) | outc;
}

static void leds_ganadores(uint8_t winner)
{
	if (winner == 1) {
		PORTB = (PORTB & ~P1_MASK) | P1_MASK;
		PORTB &= ~P2_MASK_B;
		PORTC &= ~P2_MASK_C;
		} else if (winner == 2) {
		PORTB &= ~P1_MASK;
		PORTB |= P2_MASK_B;
		PORTC |= P2_MASK_C;
	}
}

// ================= CONTADOR DE D�CADAS (0..9) =================
static inline uint8_t decade_inc(uint8_t x)
{
	x++;
	if (x >= 10) x = 0;
	return x;
}

// ================= JUEGO =================
typedef enum { ST_IDLE=0, ST_COUNTDOWN, ST_RUN, ST_WIN } State;
static State state = ST_IDLE;

static uint8_t countdown_val = 5;
static uint32_t countdown_last = 0;

static uint8_t p1 = 0, p2 = 0;   // contadores de d�cadas (0..9)
static uint8_t ganador = 0;

// META: primer jugador que llegue a 9 gana
#define GOAL 9

static void conteo_regresivo(void)
{
	countdown_val = 5;
	countdown_last = millis();
	state = ST_COUNTDOWN;
	sevenseg_show_digit(countdown_val);
}

static void reset_game(void)
{
	p1 = 0; p2 = 0; ganador = 0;
	state = ST_IDLE;
	sevenseg_show_digit(0);
	leds_contadores(p1, p2);
}

static void game_task(void)
{
	uint8_t ev_start = take_event(&b_start);
	uint8_t ev_j1    = take_event(&b_j1);
	uint8_t ev_j2    = take_event(&b_j2);

	switch(state)
	{
		case ST_IDLE:
		sevenseg_show_digit(0);
		leds_contadores(p1, p2);

		if (ev_start) conteo_regresivo();
		break;

		case ST_COUNTDOWN:
		// Durante conteo: NO se permite incrementar
		(void)ev_j1; (void)ev_j2;

		if ((millis() - countdown_last) >= 1000) {
			countdown_last += 1000;

			if (countdown_val > 0) {
				countdown_val--;
				sevenseg_show_digit(countdown_val);
				} else {
				// Carrera habilitada
				state = ST_RUN;
				sevenseg_show_digit(0);
			}
		}
		break;

		case ST_RUN:
		if (ev_j1) {
			p1 = decade_inc(p1);
			if (p1 == GOAL) { ganador = 1; state = ST_WIN; }
		}
		if (ev_j2) {
			p2 = decade_inc(p2);
			if (p2 == GOAL) { ganador = 2; state = ST_WIN; }
		}

		leds_contadores(p1, p2);

		if (ev_start) reset_game();
		break;

		case ST_WIN:
		leds_ganadores(ganador);
		sevenseg_show_digit(ganador);

		if (ev_start) {
			p1 = 0; p2 = 0; ganador = 0;
			conteo_regresivo();
			leds_contadores(0,0);
		}
		break;
	}
}

// ================= SETUP =================
static void buttons_init(void)
{
	DDRC &= ~((1<<BTN_START)|(1<<BTN_J1)|(1<<BTN_J2));
	PORTC |=  (1<<BTN_START)|(1<<BTN_J1)|(1<<BTN_J2); // pull-ups
}

static void clock_prescaler_1mhz(void)
{
	CLKPR = (1<<CLKPCE);
	CLKPR = (1<<CLKPS2); // /16 
}

int main(void)
{
	clock_prescaler_1mhz();

	sevenseg_init();
	buttons_init();
	leds_init();
	timer0_init_1ms();
	sei();

	reset_game();

	while (1)
	{
		debounce_task();
		game_task();
	}
}