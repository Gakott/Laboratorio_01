/*
 * sevenseg.c
 *
 * Created: 21/01/2026 23:03:47
 *  Author: Usuario Dell
 */ 
#include "sevenseg.h"
#include <avr/io.h>
#include <stdint.h>


// Tabla para segmentos (a..g) en bits 0..6
// bit0=a, bit1=b, bit2=c, bit3=d, bit4=e, bit5=f, bit6=g
// 1 = encendido (para c�todo com�n)
// 0 = encendido (para anodo comun)
static const uint8_t digit_map[10] = {
	// abcdefg catodo
	
	0b0111111, // 0
	0b0000110, // 1
	0b1011011, // 2
	0b1001111, // 3
	0b1100110, // 4
	0b1101101, // 5
	0b1111101, // 6
	0b0000111, // 7
	0b1111111, // 8
	0b1101111  // 9
	
	// abcdefg anodo
	/*
	0b1000000, // 0
	0b1111001, // 1
	0b0100100, // 2
	0b0110000, // 3
	0b0011001, // 4
	0b0010010, // 5
	0b0000010, // 6
	0b1111000, // 7
	0b0000000, // 8
	0b0010000  // 9
	*/
};

// ====== MAPE0 REAL ======
// a -> PD6
// b -> PD5
// c -> PD2
// d -> PD3
// e -> PD4
// f -> PD7
// g -> PD8
#define SEG_MASK_D   ((1<<PD2)|(1<<PD3)|(1<<PD4)|(1<<PD5)|(1<<PD6)|(1<<PD7)) // c d e b a f en PORTD
#define SEG_MASK_B   (1<<PB0)                                                // g en PORTB

static void write_segments(uint8_t abcdefg_bits)
{
	uint8_t d_on = 0;
	uint8_t b_on = 0;

	// a -> PD6
	if (abcdefg_bits & (1<<0)) d_on |= (1<<PD6);
	// b -> PD5
	if (abcdefg_bits & (1<<1)) d_on |= (1<<PD5);
	// c -> PD2
	if (abcdefg_bits & (1<<2)) d_on |= (1<<PD2);
	// d -> PD3
	if (abcdefg_bits & (1<<3)) d_on |= (1<<PD3);
	// e -> PD4
	if (abcdefg_bits & (1<<4)) d_on |= (1<<PD4);
	// f -> PD7
	if (abcdefg_bits & (1<<5)) d_on |= (1<<PD7);
	// g -> PB0
	if (abcdefg_bits & (1<<6)) b_on |= (1<<PB0);

	uint8_t d_out = (d_on ^ SEG_MASK_D) & SEG_MASK_D; 
	uint8_t b_out = (b_on ^ SEG_MASK_B) & SEG_MASK_B;

	PORTD = (PORTD & ~SEG_MASK_D) | d_out;
	PORTB = (PORTB & ~SEG_MASK_B) | b_out;
}

void sevenseg_init(void)
{
	DDRD |= SEG_MASK_D;
	DDRB |= SEG_MASK_B;

	sevenseg_blank();
}

void sevenseg_blank(void)
{
	// �NODO COM�N: OFF = 1 en cada segmento
	PORTD = (PORTD & ~SEG_MASK_D) | SEG_MASK_D;
	PORTB = (PORTB & ~SEG_MASK_B) | SEG_MASK_B;
}

void sevenseg_show_digit(uint8_t digit)
{
	if (digit > 9) {
		sevenseg_blank();
		return;
	}

	write_segments(digit_map[digit] & 0x7F);
}